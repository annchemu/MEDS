<?php
class Test_Identification_Model extends CI_Model{

	function Test_Identification_Model(){
		parent::__construct();
	}

	function save_identification_assay(){
		$results_assay=$this->input->post('results_assay');
		$comment_assay=$this->input->post('comment_assay');
		$coa_method_used=$this->input->post('coa_method_used');
		$coa_results=$this->input->post('coa_results');
		$coa_specification=$this->input->post('coa_specification');
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$status =1;
		$test_type='Identification as per Assay';
		$analyst= $this->input->post('analyst');

		
		$data =array(
			'results_assay'=>$results_assay,
			'comment_assay'=>$comment_assay,
			'choice'=>$this->input->post('choice'),
			'supervisor'=>$this->input->post('supervisor'),
			'date'=>$this->input->post('date'),
			'further_comments'=>$this->input->post('further_comments'),
			'status' =>$status,
			'test_request'=>$test_request,
			'assignment'=>$assignment,
			);
		$this->db->insert('identification_from_assay', $data);

		$coa_data = array('coa_method_used'=>$coa_method_used,
			'coa_results'=>$coa_results,
			'coa_specification'=>$coa_specification,
			'test_request_id'=>$test_request,
			'assignment_id'=>$assignment,
			'test_type'=>$test_type,
			'analyst'=>$analyst,
			);
		$this->db->insert('coa', $coa_data);

		redirect('test/index/'.$assignment.'/'.$test_request);


	}
	function save_identification_uv(){
		$status =1;
		
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$test_specification=$this->input->post('test_specification');
		$test_type='Identification by UV';
		$analyst= $this->input->post('analyst');
				
		
		$data =array(
			'uv_sample_weight'=>$this->input->post('uv_sample_weight'),
			'uv_calculation'=>$this->input->post('uv_calculation'),
			'uv_sample_container'=>$this->input->post('uv_sample_container'),
			'uv_container'=>$this->input->post('uv_container'),
			'uv_sample_weight_1'=>$this->input->post('uv_sample_weight_1'),
			'uv_sample_dilution'=>$this->input->post('uv_sample_dilution'),
			'uv_standard_description'=>$this->input->post('uv_standard_description'),
			'uv_potency'=>$this->input->post('uv_potency'),
			'uv_lot_no'=>$this->input->post('uv_lot_no'),
			'uv_id_no'=>$this->input->post('uv_id_no'),

			'uv_potency_standard_container'=>$this->input->post('uv_potency_standard_container'),
			'uv_potency_standard_container_2'=>$this->input->post('uv_potency_standard_container_2'),
			'uv_potency_container'=>$this->input->post('uv_potency_container'),
			'uv_potency_container_2'=>$this->input->post('uv_potency_container_2'),
			'uv_standard_weight'=>$this->input->post('uv_standard_weight'),
			'uv_standard_weight_2'=>$this->input->post('uv_standard_weight_2'),
			'uv_standard_dilution'=>$this->input->post('uv_standard_dilution'),
			'uv_acceptance_criteria'=>$this->input->post('acceptance_criteria'),
			'uv_results'=>$this->input->post('uv_results'),
			'uv_comment'=>$this->input->post('uv_comment'),

			'uv_potency_reagent_container'=>$this->input->post('uv_potency_reagent_container'),
			'uv_potency_reagent_container_2'=>$this->input->post('uv_potency_reagent_container_2'),
			'uv_potency_reagent_container_3'=>$this->input->post('uv_potency_reagent_container_3'),
			'uv_potency_reagent_container_4'=>$this->input->post('uv_potency_reagent_container_4'),
			'uv_reagent_container'=>$this->input->post('uv_reagent_container'),
			'uv_reagent_container_2'=>$this->input->post('uv_reagent_container_2'),
			'uv_reagent_container_3'=>$this->input->post('uv_reagent_container_3'),
			'uv_reagent_container_4'=>$this->input->post('uv_reagent_container_4'),
			'uv_reagent_weight'=>$this->input->post('uv_reagent_weight'),
			'uv_reagent_weight_2'=>$this->input->post('uv_reagent_weight_2'),
			'uv_reagent_weight_3'=>$this->input->post('uv_reagent_weight_3'),
			'uv_reagent_weight_4'=>$this->input->post('uv_reagent_weight_4'),
			
			'uv_acceptance_criteria'=>$this->input->post('uv_acceptance_criteria'),
			'uv_results'=>$this->input->post('uv_results'),
			'uv_comment'=>$this->input->post('uv_comment'),

			'choice'=>$this->input->post('choice'),
			'done_by'=>$this->input->post('done_by'),
			'date_done'=>$this->input->post('date_done'),
			'supervisor'=>$this->input->post('supervisor'),
			'date'=>$this->input->post('date'),
			'further_comments'=>$this->input->post('further_comments'),
			'status' =>$status,
			'test_request'=>$test_request,
			'assignment'=>$assignment,				

			);
		$this->db->insert('identification_uv', $data);

		$coa_data = array(			
			'test_request_id'=>$test_request,
			'assignment_id'=>$assignment,
			'test_type'=>$test_type,
			// 'test_specification'=>$test_specification,
			// 'results'=>$this->input->post('further_comments'),
			'remarks'=>$this->input->post('choice'),
			'date_done'=>$this->input->post('date_done'),
			'done_by'=>$analyst,
			);
		$this->db->insert('coa', $coa_data);

		redirect('test/index/'.$assignment.'/'.$test_request);

	}
	
	function save_identification_infrared(){
		$status =1;		
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$test_specification=$this->input->post('test_specification');
		$test_type='Identification by UV';
		$analyst= $this->input->post('analyst');

		$data =array(
			
			'equipment_make'=>$this->input->post('equipment_make'),
			'balance_number'=>$this->input->post('balance_number'),
			'infrared_sample_weight'=>$this->input->post('infrared_sample_weight'),
			'infrared_calculation'=>$this->input->post('infrared_calculation'),
			'infrared_sample_container'=>$this->input->post('infrared_sample_container'),
			'infrared_container'=>$this->input->post('infrared_container'),
			'infrared_sample_weight_1'=>$this->input->post('infrared_sample_weight_1'),
			'infrared_sample_dilution'=>$this->input->post('infrared_sample_dilution'),
			'standard_description'=>$this->input->post('standard_description'),
			'potency'=>$this->input->post('potency'),
			'lot_no'=>$this->input->post('lot_no'),
			'id_no'=>$this->input->post('id_no'),
			'infrared_standard_container'=>$this->input->post('infrared_standard_container'),
			'infrared_container_2'=>$this->input->post('infrared_container_2'),
 			'infrared_standard_weight'=>$this->input->post('infrared_standard_weight'),
			'infrared_standard_dilution'=>$this->input->post('infrared_standard_dilution'),
			'infrared_acceptance_criteria'=>$this->input->post('infrared_acceptance_criteria'),
			'infrared_results'=>$this->input->post('infrared_results'),
			'infrared_comment'=>$this->input->post('infrared_comment'),
			'choice'=>$this->input->post('choice'),
			'analyst'=>$this->input->post('done_by'),
			'date_done'=>$this->input->post('date_done'),
			'supervisor'=>$this->input->post('supervisor'),
			'date'=>$this->input->post('date'),
			'further_comments'=>$this->input->post('further_comments'),
			'status' =>$status,
			'test_request'=>$this->input->post('test_request'),
			'assignment'=>$this->input->post('assignment')
			);
		$this->db->insert('identification_infrared', $data);	

		$coa_data = array(			
			'test_request_id'=>$test_request,
			'assignment_id'=>$assignment,
			'test_type'=>$test_type,
			'test_specification'=>$test_specification,
			// 'results'=>$this->input->post('further_comments'),
			'remarks'=>$this->input->post('choice'),
			'date_done'=>$this->input->post('date_done'),
			'done_by'=>$analyst,
			);
		$this->db->insert('coa', $coa_data);
		redirect('test/index/'.$assignment.'/'.$test_request);	
	}
	
	function save_assay_monograph(){
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$test_name='Identification: Assay';
		$analyst= $this->input->post('analyst');
		$identification_assay_id= 1;


		$data = array(
			'monograph' => $this->input->post('assay_monograph'),
			'test_request_id' => $this->input->post('test_request'),
			'assignment_id' => $this->input->post('assignment'),
			'test_name' => $test_name,
			'analyst' => $this->input->post('analyst'),
			'identification_assay_id' => $identification_assay_id

			);
		$this->db->insert('identification_assay_monograph', $data);
		redirect('test/index/'.$assignment.'/'.$test_request);	

	}
	function save_infrared_monograph(){
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$test_name='Identification: Infrared';
		$analyst= $this->input->post('analyst');
		$identification_infrared_id= 1;


		$data = array(
			'monograph' => $this->input->post('infrared_monograph'),
			'test_request_id' => $this->input->post('test_request'),
			'assignment_id' => $this->input->post('assignment'),
			'test_name' => $test_name,
			'analyst' => $this->input->post('analyst'),
			'specification' => $this->input->post('specification'),
			'identification_infrared_id' => $identification_infrared_id


			);
		$this->db->insert('identification_infrared_monograph', $data);
		redirect('test/index/'.$assignment.'/'.$test_request);	

	}
	function save_tlc_monograph(){
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$test_name='Identification: TLC';
		$analyst= $this->input->post('analyst');
		$identification_tlc_id= 1;


		$data = array(
			'monograph' => $this->input->post('tlc_monograph'),
			'test_request_id' => $this->input->post('test_request'),
			'assignment_id' => $this->input->post('assignment'),
			'test_name' => $test_name,
			'analyst' => $this->input->post('analyst'),
			'identification_tlc_id' => $identification_tlc_id


			);
		$this->db->insert('identification_tlc_monograph', $data);
		redirect('test/index/'.$assignment.'/'.$test_request);	

	}
	function save_uv_monograph(){
		$test_request=$this->input->post('test_request');
		$assignment=$this->input->post('assignment');
		$test_name='Identification: UV';
		$analyst= $this->input->post('analyst');
		$identification_uv_id= 1;


		$data = array(
			'monograph' => $this->input->post('uv_monograph'),
			'test_request_id' => $this->input->post('test_request'),
			'assignment_id' => $this->input->post('assignment'),
			'test_name' => $test_name,
			'specification' => $this->input->post('specification'),
			'analyst' => $this->input->post('analyst'),
			'identification_uv_id' => $identification_uv_id,


			);
		$this->db->insert('identification_uv_monograph', $data);
		redirect('test/index/'.$assignment.'/'.$test_request);	

	}

}

?> 